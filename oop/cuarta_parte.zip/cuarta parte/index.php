<?php

//Requerimos los archivos

require ("./model/Vehiculo.php");
require ("./controller/VehiculoController.php");

//Instanciamos el controlador
$controller = new VehiculoController();

//Ruta principal
$home= "C:\xampp\htdocs\modulo_poo_2\cuarta parte\index.php";

//Retiramos el home de la ruta
$ruta= str_replace($home, "", $_SERVER["REQUEST_URI"]);

//filtramos la ruta
$array_ruta=array_filter(explode("/", $ruta));

if(isset($array_ruta[0]) && $array_ruta[0]!="vista" && is_numeric($array_ruta[1])){
    //vista en ruta 1
    $controller->vista($array_ruta[1]);

}
else{
    //llamamos vista por defecto
    $controller->index();
}
